import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Calendar, Users, Building2, ArrowRight } from "lucide-react"
import HeroSection from "@/components/hero-section"
import ScheduleSection from "@/components/schedule-section"
import SpeakersSection from "@/components/speakers-section"
import PartnersSection from "@/components/partners-section"

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      <header className="sticky top-0 z-40 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center">
          <div className="mr-4 hidden md:flex">
            <Link href="/" className="mr-6 flex items-center space-x-2">
              <span className="hidden font-bold sm:inline-block">Academic Week of Statistics</span>
            </Link>
            <nav className="flex items-center space-x-6 text-sm font-medium">
              <Link href="#schedule" className="transition-colors hover:text-foreground/80">
                Schedule
              </Link>
              <Link href="#speakers" className="transition-colors hover:text-foreground/80">
                Speakers
              </Link>
              <Link href="#partners" className="transition-colors hover:text-foreground/80">
                Partners
              </Link>
            </nav>
          </div>
          <div className="flex flex-1 items-center justify-between space-x-2 md:justify-end">
            <div className="w-full flex-1 md:w-auto md:flex-none">
              <Button className="w-full md:w-auto">Register Now</Button>
            </div>
          </div>
        </div>
      </header>
      <main className="flex-1">
        <HeroSection />

        <div id="schedule" className="py-12 md:py-24 bg-muted/50">
          <div className="container px-4 md:px-6">
            <div className="flex items-center gap-4">
              <Calendar className="h-6 w-6 text-primary" />
              <h2 className="text-3xl font-bold tracking-tighter">Event Schedule</h2>
            </div>
            <ScheduleSection />
          </div>
        </div>

        <div id="speakers" className="py-12 md:py-24">
          <div className="container px-4 md:px-6">
            <div className="flex items-center gap-4">
              <Users className="h-6 w-6 text-primary" />
              <h2 className="text-3xl font-bold tracking-tighter">Featured Speakers</h2>
            </div>
            <SpeakersSection />
          </div>
        </div>

        <div id="partners" className="py-12 md:py-24 bg-muted/50">
          <div className="container px-4 md:px-6">
            <div className="flex items-center gap-4">
              <Building2 className="h-6 w-6 text-primary" />
              <h2 className="text-3xl font-bold tracking-tighter">Our Partners</h2>
            </div>
            <PartnersSection />
          </div>
        </div>

        <div className="py-12 md:py-24">
          <div className="container px-4 md:px-6 text-center">
            <h2 className="text-3xl font-bold tracking-tighter md:text-4xl/tight">
              Join Us for an Exciting Week of Statistical Learning
            </h2>
            <p className="mx-auto mt-4 max-w-[700px] text-muted-foreground md:text-xl">
              Don't miss this opportunity to expand your knowledge, network with professionals, and explore career
              opportunities in statistics and data science.
            </p>
            <div className="mt-8">
              <Button size="lg" className="gap-2">
                Register for the Event <ArrowRight className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </main>
      <footer className="border-t py-6 md:py-0">
        <div className="container flex flex-col items-center justify-between gap-4 md:h-24 md:flex-row">
          <p className="text-center text-sm leading-loose text-muted-foreground md:text-left">
            © {new Date().getFullYear()} Academic Week of Statistics. All rights reserved.
          </p>
          <div className="flex items-center gap-4">
            <Link href="#" className="text-sm text-muted-foreground underline-offset-4 hover:underline">
              Contact
            </Link>
            <Link href="#" className="text-sm text-muted-foreground underline-offset-4 hover:underline">
              Privacy
            </Link>
          </div>
        </div>
      </footer>
    </div>
  )
}
